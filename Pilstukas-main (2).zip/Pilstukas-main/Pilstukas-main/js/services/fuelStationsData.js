export function getFuelStations() {
    return [
    {
        "id": "baltic-petroleum-baltic-petroleum-54-3864789-24-0330459",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Santaikos g. 33, Alytus, 62123",
        "city": "Alytus",
        "lat": 54.3864789,
        "lon": 24.0330459,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-5085163-25-0961825",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Mindaugo g. 23C, Anykščiai, 29141",
        "city": "Anykščiai",
        "lat": 55.5085163,
        "lon": 25.0961825,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-5226029-25-0879999",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "A. Vienuolio g. 34A, Anykščiai",
        "city": "Anykščiai",
        "lat": 55.5226029,
        "lon": 25.0879999,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-56-0708348-24-4111772",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Mūšos g. 19, Aukštikalniai, 39103",
        "city": "Aukštikalniai",
        "lat": 56.0708348,
        "lon": 24.4111772,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-53-9998932-23-9879595",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Gardino g. 79, Druskininkai, 66191",
        "city": "Druskininkai",
        "lat": 53.9998932,
        "lon": 23.9879595,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-0302435-23-9832836",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Leipalingio g. 26, Druskininkai, 66371",
        "city": "Druskininkai",
        "lat": 54.0302435,
        "lon": 23.9832836,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-6810057-25-4119923",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Pavilnės g. 1, Grigaičiai",
        "city": "Grigaičiai",
        "lat": 54.6810057,
        "lon": 25.4119923,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-8522337-23-1769432",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Antano Skelčio g. 4, Griškabūdis, 71291",
        "city": "Griškabūdis",
        "lat": 54.8522337,
        "lon": 23.1769432,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-0382973-23-6078065",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Degalinės g. 1, Jaučakiai",
        "city": "Jaučakiai",
        "lat": 55.0382973,
        "lon": 23.6078065,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-0823622-24-2709386",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Žemaitės g. 1, Jonava, 55134",
        "city": "Jonava",
        "lat": 55.0823622,
        "lon": 24.2709386,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-3355923-23-1023266",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "1, Kalnujai",
        "city": "Kalnujai",
        "lat": 55.3355923,
        "lon": 23.1023266,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-8613556-23-9588064",
        "brand": "Baltic Petroleum",
        "name": "Baltic petroleum",
        "address": "Vaidoto g. 153, Kaunas",
        "city": "Kaunas",
        "lat": 54.8613556,
        "lon": 23.9588064,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-8856955-23-9119635",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "H. ir O. Minkovskių g. 132, Kaunas, 46245",
        "city": "Kaunas",
        "lat": 54.8856955,
        "lon": 23.9119635,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-9050259-23-899559",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Jonavos g. 60A, Kaunas",
        "city": "Kaunas",
        "lat": 54.9050259,
        "lon": 23.899559,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-903137-23-9827343",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Chemijos g. 6, Kaunas",
        "city": "Kaunas",
        "lat": 54.903137,
        "lon": 23.9827343,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-9173759-24-0348002",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Taikos pr. 120, Kaunas, 52140",
        "city": "Kaunas",
        "lat": 54.9173759,
        "lon": 24.0348002,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-9077623-23-874128",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Raudondvario pl. 82, Kaunas, 47182",
        "city": "Kaunas",
        "lat": 54.9077623,
        "lon": 23.874128,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-7049578-21-1635571",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Šilutės pl. 1, Klaipėda, 91109",
        "city": "Klaipėda",
        "lat": 55.7049578,
        "lon": 21.1635571,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-7208155-21-1524956",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Liepų g. 79A, Klaipėda",
        "city": "Klaipėda",
        "lat": 55.7208155,
        "lon": 21.1524956,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-0946203-23-8714383",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Merkinės g. 37, Leipalingis, 67280",
        "city": "Leipalingis",
        "lat": 54.0946203,
        "lon": 23.8714383,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-38774-23-9958332",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Senojo Plento g. 1G, Likiškėliai",
        "city": "Likiškėliai",
        "lat": 54.38774,
        "lon": 23.9958332,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-533804-23-353361",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "P. Armino g. 69, Marijampolė, 68127",
        "city": "Marijampolė",
        "lat": 54.533804,
        "lon": 23.353361,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-5556749-23-3754953",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Vasaros g. 15, Marijampolė, 68114",
        "city": "Marijampolė",
        "lat": 54.5556749,
        "lon": 23.3754953,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-1691323-24-2077437",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Vilniaus g. 87, Merkinė, 65333",
        "city": "Merkinė",
        "lat": 54.1691323,
        "lon": 24.2077437,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-2173358-25-4033091",
        "brand": "Baltic Petroleum",
        "name": "Baltic petroleum",
        "address": "Vilniaus g. 104, Molėtai, 33114",
        "city": "Molėtai",
        "lat": 55.2173358,
        "lon": 25.4033091,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-3008802-20-9798761",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Nidos-Smiltynės pl. 6, Neringa",
        "city": "Neringa",
        "lat": 55.3008802,
        "lon": 20.9798761,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-7964672-24-8888414",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Parko g. 3A, Noriūnai",
        "city": "Noriūnai",
        "lat": 55.7964672,
        "lon": 24.8888414,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-7304558-22-3767964",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Dariaus ir Girėno g. 77, Ožtakiai",
        "city": "Ožtakiai",
        "lat": 55.7304558,
        "lon": 22.3767964,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-7398454-25-8521638",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Vytauto Striogos g. 4A, Padustėlis",
        "city": "Padustėlis",
        "lat": 55.7398454,
        "lon": 25.8521638,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-marijampoles-g-1-pagiriai-53283-54-8146128-23-8725798",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum Marijampolės g. 1, Pagiriai, 53283",
        "address": "Marijampolės g. 1, Pagiriai, 53283",
        "city": "Pagiriai",
        "lat": 54.8146128,
        "lon": 23.8725798,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-9744609-23-8689349",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Statybininkų g. 28, Pakruojis, 83182",
        "city": "Pakruojis",
        "lat": 55.9744609,
        "lon": 23.8689349,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-56-0128803-21-1037154",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Elijos g. 26, Palanga, 00319",
        "city": "Palanga",
        "lat": 56.0128803,
        "lon": 21.1037154,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-9156224-21-0783791",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Klaipėdos pl. 44, Palanga, 00111",
        "city": "Palanga",
        "lat": 55.9156224,
        "lon": 21.0783791,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-56-0192095-25-2221729",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Elektrinės g. 1, Pandėlys",
        "city": "Pandėlys",
        "lat": 56.0192095,
        "lon": 25.2221729,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-7531721-24-312038",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Pušaloto g. 193A, Panevėžys, 35291",
        "city": "Panevėžys",
        "lat": 55.7531721,
        "lon": 24.312038,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-7218721-24-3914527",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Velžio kel. 74, Panevėžys, 36148",
        "city": "Panevėžys",
        "lat": 55.7218721,
        "lon": 24.3914527,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-7575904-24-3677123",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Smėlynės g. 169, Panevėžys",
        "city": "Panevėžys",
        "lat": 55.7575904,
        "lon": 24.3677123,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-3223462-23-1451986",
        "brand": "Baltic Petroleum",
        "name": "Baltic petroleum",
        "address": "Europos g. 12, Pasiekos, 69270",
        "city": "Pasiekos",
        "lat": 54.3223462,
        "lon": 23.1451986,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-5869007-23-384638",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Kauno g. 164, Pietariai",
        "city": "Pietariai",
        "lat": 54.5869007,
        "lon": 23.384638,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-5619026-21-3087374",
        "brand": "Baltic Petroleum",
        "name": "Baltic petroleum",
        "address": "Klaipėdos g. 61, Priekulė, 96342",
        "city": "Priekulė",
        "lat": 55.5619026,
        "lon": 21.3087374,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-6284881-23-9586526",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Vilniaus g. 3A, Prienai, 59115",
        "city": "Prienai",
        "lat": 54.6284881,
        "lon": 23.9586526,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-8255781-23-5234205",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Šiaulių g. 1A, Radviliškis, 82142",
        "city": "Radviliškis",
        "lat": 55.8255781,
        "lon": 23.5234205,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-3709617-23-1331381",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Vilniaus g. 30, Raseiniai, 60183",
        "city": "Raseiniai",
        "lat": 55.3709617,
        "lon": 23.1331381,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-7194009-21-9285021",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Dariaus ir Girėno g. 19, Rietavas, 90316",
        "city": "Rietavas",
        "lat": 55.7194009,
        "lon": 21.9285021,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-8894586-23-8046471",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Gėlių g. 1A, Ringaudai",
        "city": "Ringaudai",
        "lat": 54.8894586,
        "lon": 23.8046471,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-9467247-25-591046",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Respublikos g. 113B, Rokiškis",
        "city": "Rokiškis",
        "lat": 55.9467247,
        "lon": 25.591046,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-7372264-26-2729486",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Vytauto g. 61, Sarakiškės, 32139",
        "city": "Sarakiškės",
        "lat": 55.7372264,
        "lon": 26.2729486,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-2564922-24-5470516",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Vilniaus g. 6A, Senoji Varėna",
        "city": "Senoji Varėna",
        "lat": 54.2564922,
        "lon": 24.5470516,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-56-2594066-21-530114",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Vytauto g. 22, Skuodas",
        "city": "Skuodas",
        "lat": 56.2594066,
        "lon": 21.530114,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-0581348-24-2634653",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Plento g. 46, Spanėnai, 55155",
        "city": "Spanėnai",
        "lat": 55.0581348,
        "lon": 24.2634653,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-9453642-23-0457682",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Sodų g. 1, Šakiai, 71136",
        "city": "Šakiai",
        "lat": 54.9453642,
        "lon": 23.0457682,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-3179455-25-381581",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Vilniaus g. 5A, Šalčininkai",
        "city": "Šalčininkai",
        "lat": 54.3179455,
        "lon": 25.381581,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-0322619-24-9671254",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Musninkų g. 21, Širvintos, 19125",
        "city": "Širvintos",
        "lat": 55.0322619,
        "lon": 24.9671254,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-56-003941-22-2447459",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Šiaulių pl. 12, Telšiai, 87101",
        "city": "Telšiai",
        "lat": 56.003941,
        "lon": 22.2447459,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-6273051-24-9485485",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Vilniaus g. 33, Trakai, 21118",
        "city": "Trakai",
        "lat": 54.6273051,
        "lon": 24.9485485,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-8169782-24-436628",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Kauno pl. 5, Triliškės, 56236",
        "city": "Triliškės",
        "lat": 54.8169782,
        "lon": 24.436628,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-2408614-24-739606",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Kauno g. 49, Ukmergė, 20118",
        "city": "Ukmergė",
        "lat": 55.2408614,
        "lon": 24.739606,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-55-4953208-25-5748447",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "J. Basanavičiaus g. 1B, Utena, 28138",
        "city": "Utena",
        "lat": 55.4953208,
        "lon": 25.5748447,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-768622-25-1959969",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Senasis Ukmergės kel. 4A, Užubaliai, 14302",
        "city": "Užubaliai",
        "lat": 54.768622,
        "lon": 25.1959969,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-56-1973494-24-7096417",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "1, Valantiškis",
        "city": "Valantiškis",
        "lat": 56.1973494,
        "lon": 24.7096417,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-2183435-24-565626",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "M. K. Čiurlionio g. 63, Varėna, 65219",
        "city": "Varėna",
        "lat": 54.2183435,
        "lon": 24.565626,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-7609694-23-7132251",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Kauno g., Veiveriai",
        "city": "Veiveriai",
        "lat": 54.7609694,
        "lon": 23.7132251,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-7222129-25-3171415",
        "brand": "Baltic Petroleum",
        "name": "Baltic petroleum",
        "address": "Antakalnio g. 128, Vilnius, 10200",
        "city": "Vilnius",
        "lat": 54.7222129,
        "lon": 25.3171415,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-7028165-25-288243",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Rinktinės g. 59, Vilnius, 09207",
        "city": "Vilnius",
        "lat": 54.7028165,
        "lon": 25.288243,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-7240433-25-282353",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Kalvarijų g. 161A, Vilnius, 08311",
        "city": "Vilnius",
        "lat": 54.7240433,
        "lon": 25.282353,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-6608366-25-2333896",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Savanorių pr. 121, Vilnius, 03150",
        "city": "Vilnius",
        "lat": 54.6608366,
        "lon": 25.2333896,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-692177-25-3466702",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Stepono Batoro g. 15, Vilnius",
        "city": "Vilnius",
        "lat": 54.692177,
        "lon": 25.3466702,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-7677118-25-2725284",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Molėtų pl. 27A, Vilnius",
        "city": "Vilnius",
        "lat": 54.7677118,
        "lon": 25.2725284,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-6404827-25-26748",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Metalo g. 4B, Vilnius",
        "city": "Vilnius",
        "lat": 54.6404827,
        "lon": 25.26748,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-6667656-25-2507961",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "Gerosios Vilties g. 33, Vilnius, 03160",
        "city": "Vilnius",
        "lat": 54.6667656,
        "lon": 25.2507961,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-54-6139256-25-3090003",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum",
        "address": "B. Brazdžionio g. 2, Vilnius",
        "city": "Vilnius",
        "lat": 54.6139256,
        "lon": 25.3090003,
        "prices": {}
    },
    {
        "id": "baltic-petroleum-baltic-petroleum-degaline-ir-plovykla-54-779293-25-3420915",
        "brand": "Baltic Petroleum",
        "name": "Baltic Petroleum degalinė ir plovykla",
        "address": "Visalaukio g. 2, Vilnius",
        "city": "Vilnius",
        "lat": 54.779293,
        "lon": 25.3420915,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-kupiskis-55-8245155-25-0010783",
        "brand": "Circle K",
        "name": "Circle K „Kupiškis“",
        "address": "Kikonių g. 10, Aleksandrija, 40334",
        "city": "Aleksandrija",
        "lat": 55.8245155,
        "lon": 25.0010783,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-alytus-ii-54-4246479-24-0035004",
        "brand": "Circle K",
        "name": "Circle K „Alytus II“",
        "address": "Naujoji g. 120, Alytus, 62175",
        "city": "Alytus",
        "lat": 54.4246479,
        "lon": 24.0035004,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-alytus-54-3950373-24-0378997",
        "brand": "Circle K",
        "name": "Circle K „Alytus“",
        "address": "Rūtų g. 2B, Alytus, 62119",
        "city": "Alytus",
        "lat": 54.3950373,
        "lon": 24.0378997,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-tarande-54-7603498-25-2015622",
        "brand": "Circle K",
        "name": "Circle K „Tarandė“",
        "address": "Sudervės g. 2G, Avižieniai, 14198",
        "city": "Avižieniai",
        "lat": 54.7603498,
        "lon": 25.2015622,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-birzai-56-1948281-24-7721504",
        "brand": "Circle K",
        "name": "Circle K „Biržai“",
        "address": "Kilučių g. 93, Biržai, 41156",
        "city": "Biržai",
        "lat": 56.1948281,
        "lon": 24.7721504,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-54-3681514-23-1837663",
        "brand": "Circle K",
        "name": "Circle K",
        "address": "Muitinės g. 5B, Brazavas, 69321",
        "city": "Brazavas",
        "lat": 54.3681514,
        "lon": 23.1837663,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-grigiskes-54-6864295-25-0540297",
        "brand": "Circle K",
        "name": "Circle K Grigiškės",
        "address": "Didžiulio g. 5, Dėdeliškės",
        "city": "Dėdeliškės",
        "lat": 54.6864295,
        "lon": 25.0540297,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-1-2-3-54-7807411-25-2739087",
        "brand": "Circle K",
        "name": "Circle K 1-2-3",
        "address": "Molėtų g. 15, Didžioji Riešė, 14262",
        "city": "Didžioji Riešė",
        "lat": 54.7807411,
        "lon": 25.2739087,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-druskininkai-54-0101814-23-9932381",
        "brand": "Circle K",
        "name": "Circle K „Druskininkai“",
        "address": "M. K. Čiurlionio g. 113, Druskininkai, 66161",
        "city": "Druskininkai",
        "lat": 54.0101814,
        "lon": 23.9932381,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-elektrenai-54-7891685-24-6760563",
        "brand": "Circle K",
        "name": "Circle K „Elektrėnai“",
        "address": "Sabališkių g. 1F, Elektrėnai, 26141",
        "city": "Elektrėnai",
        "lat": 54.7891685,
        "lon": 24.6760563,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-sakiai-54-9527136-23-0832721",
        "brand": "Circle K",
        "name": "Circle K „Šakiai“",
        "address": "Kauno g. 68, Girėnai, 71129",
        "city": "Girėnai",
        "lat": 54.9527136,
        "lon": 23.0832721,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-jonusai-55-7113503-21-2630646",
        "brand": "Circle K",
        "name": "Circle K „Jonušai“",
        "address": "Vilniaus pl. 21, Jakai, 92498",
        "city": "Jakai",
        "lat": 55.7113503,
        "lon": 21.2630646,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-jurbarkas-55-0767987-22-7518842",
        "brand": "Circle K",
        "name": "Circle K „Jurbarkas“",
        "address": "Muitinės g. 34A, Jurbarkas, 74106",
        "city": "Jurbarkas",
        "lat": 55.0767987,
        "lon": 22.7518842,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-54-908154-23-8652669",
        "brand": "Circle K",
        "name": "Circle K",
        "address": "Raudondvario pl. 107A, Kaunas, 47186",
        "city": "Kaunas",
        "lat": 54.908154,
        "lon": 23.8652669,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-aleksotas-54-8809074-23-8942285",
        "brand": "Circle K",
        "name": "Circle K „Aleksotas“",
        "address": "Veiverių g. 49A, Kaunas",
        "city": "Kaunas",
        "lat": 54.8809074,
        "lon": 23.8942285,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-barsausko-54-8990483-23-9599257",
        "brand": "Circle K",
        "name": "Circle K „Baršausko“",
        "address": "K. Baršausko g. 57, Kaunas, 51423",
        "city": "Kaunas",
        "lat": 54.8990483,
        "lon": 23.9599257,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-dainava-54-9162307-23-9866749",
        "brand": "Circle K",
        "name": "Circle K „Dainava“",
        "address": "Pramonės pr. 18, Kaunas, 51183",
        "city": "Kaunas",
        "lat": 54.9162307,
        "lon": 23.9866749,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-greitkelis-i-54-935091-23-9662932",
        "brand": "Circle K",
        "name": "Circle K „Greitkelis I“",
        "address": "Briedžių tak. 6C, Kaunas, 49106",
        "city": "Kaunas",
        "lat": 54.935091,
        "lon": 23.9662932,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-greitkelis-ii-54-933611-23-9657729",
        "brand": "Circle K",
        "name": "Circle K „Greitkelis II“",
        "address": "Islandijos pl. 61C, Kaunas, 49117",
        "city": "Kaunas",
        "lat": 54.933611,
        "lon": 23.9657729,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-ix-fortas-54-9356046-23-8701462",
        "brand": "Circle K",
        "name": "Circle K „IX Fortas“",
        "address": "Vakarinis aplinkl. 10, Kaunas, 48182",
        "city": "Kaunas",
        "lat": 54.9356046,
        "lon": 23.8701462,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-jonavos-54-9015799-23-8950211",
        "brand": "Circle K",
        "name": "Circle K „Jonavos“",
        "address": "Jonavos g. 38, Kaunas, 44263",
        "city": "Kaunas",
        "lat": 54.9015799,
        "lon": 23.8950211,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-murava-2-54-9283579-23-9739104",
        "brand": "Circle K",
        "name": "Circle K „Murava 2“",
        "address": "Savanorių pr. 404B, Kaunas, 50302",
        "city": "Kaunas",
        "lat": 54.9283579,
        "lon": 23.9739104,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-petrasiunai-54-8940448-24-0065985",
        "brand": "Circle K",
        "name": "Circle K „Petrašiūnai“",
        "address": "R. Kalantos g. 159, Kaunas, 52314",
        "city": "Kaunas",
        "lat": 54.8940448,
        "lon": 24.0065985,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-savanoriu-54-9201429-23-9528364",
        "brand": "Circle K",
        "name": "Circle K „Savanorių“",
        "address": "Savanorių pr. 321B, Kaunas, 50120",
        "city": "Kaunas",
        "lat": 54.9201429,
        "lon": 23.9528364,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-sukileliu-54-9284023-23-9289703",
        "brand": "Circle K",
        "name": "Circle K „Sukilėlių“",
        "address": "Sukilėlių pr. 120, Kaunas, 49237",
        "city": "Kaunas",
        "lat": 54.9284023,
        "lon": 23.9289703,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-silainiai-54-9252655-23-8904885",
        "brand": "Circle K",
        "name": "Circle K „Šilainiai“",
        "address": "Žemaičių pl. 19, Kaunas, 48255",
        "city": "Kaunas",
        "lat": 54.9252655,
        "lon": 23.8904885,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-taika-54-9119336-23-956739",
        "brand": "Circle K",
        "name": "Circle K „Taika“",
        "address": "Taikos pr. 52A, Kaunas, 51305",
        "city": "Kaunas",
        "lat": 54.9119336,
        "lon": 23.956739,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-tvirtoves-54-9131489-23-9260736",
        "brand": "Circle K",
        "name": "Circle K „Tvirtovės“",
        "address": "Tvirtovės al. 33A, Kaunas, 50157",
        "city": "Kaunas",
        "lat": 54.9131489,
        "lon": 23.9260736,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-1-2-3-kalanta-54-8930507-23-9958043",
        "brand": "Circle K",
        "name": "Circle K 1-2-3 „Kalanta“",
        "address": "R. Kalantos g. 68, Kaunas, 52365",
        "city": "Kaunas",
        "lat": 54.8930507,
        "lon": 23.9958043,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-1-2-3-mega-54-9383582-23-898308",
        "brand": "Circle K",
        "name": "Circle K 1-2-3 „Mega“",
        "address": "Islandijos pl. 32A, Kaunas, 47446",
        "city": "Kaunas",
        "lat": 54.9383582,
        "lon": 23.898308,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-1-2-3-silkas-54-9144567-23-9002271",
        "brand": "Circle K",
        "name": "Circle K 1-2-3 „Šilkas“",
        "address": "Varnių g. 46, Kaunas, 48403",
        "city": "Kaunas",
        "lat": 54.9144567,
        "lon": 23.9002271,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-karaliaus-mindaugo-pr-54-8941634-23-9142006",
        "brand": "Circle K",
        "name": "Circle K Karaliaus Mindaugo pr.",
        "address": "Karaliaus Mindaugo pr. 34A, Kaunas, 44306",
        "city": "Kaunas",
        "lat": 54.8941634,
        "lon": 23.9142006,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-kedainiai-55-2865785-23-9721863",
        "brand": "Circle K",
        "name": "Circle K „Kėdainiai“",
        "address": "J. Basanavičiaus g. 40A, Kėdainiai, 57295",
        "city": "Kėdainiai",
        "lat": 55.2865785,
        "lon": 23.9721863,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-jurininkai-55-6566546-21-1824418",
        "brand": "Circle K",
        "name": "Circle K „Jūrininkai“",
        "address": "Jūrininkų pr. 31, Klaipėda, 95225",
        "city": "Klaipėda",
        "lat": 55.6566546,
        "lon": 21.1824418,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-miskas-55-7303183-21-1247329",
        "brand": "Circle K",
        "name": "Circle K „Miškas“",
        "address": "H. Manto g. 96, Klaipėda, 92295",
        "city": "Klaipėda",
        "lat": 55.7303183,
        "lon": 21.1247329,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-perkela-55-687592-21-1448579",
        "brand": "Circle K",
        "name": "Circle K „Perkėla“",
        "address": "Minijos g. 90, Klaipėda, 93234",
        "city": "Klaipėda",
        "lat": 55.687592,
        "lon": 21.1448579,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-pilies-g-55-7020689-21-1380344",
        "brand": "Circle K",
        "name": "Circle K „Pilies g.“",
        "address": "Sausio 15-osios g. 2, Klaipėda, 91200",
        "city": "Klaipėda",
        "lat": 55.7020689,
        "lon": 21.1380344,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-sendvaris-55-7041492-21-1608983",
        "brand": "Circle K",
        "name": "Circle K „Sendvaris“",
        "address": "Tilžės g. 56A, Klaipėda, 91110",
        "city": "Klaipėda",
        "lat": 55.7041492,
        "lon": 21.1608983,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-smiltele-55-666436-21-172644",
        "brand": "Circle K",
        "name": "Circle K „Smiltelė“",
        "address": "Taikos pr. 112A, Klaipėda, 93150",
        "city": "Klaipėda",
        "lat": 55.666436,
        "lon": 21.172644,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-ziedas-55-6927888-21-179784",
        "brand": "Circle K",
        "name": "Circle K „Žiedas“",
        "address": "Vilniaus pl. 1A, Klaipėda, 94105",
        "city": "Klaipėda",
        "lat": 55.6927888,
        "lon": 21.179784,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-1-2-3-taika-55-692421-21-153759",
        "brand": "Circle K",
        "name": "Circle K 1-2-3 „Taika“",
        "address": "Taikos pr. 61B, Klaipėda, 91182",
        "city": "Klaipėda",
        "lat": 55.692421,
        "lon": 21.153759,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-kryzkalnis-2-55-4843351-22-5879147",
        "brand": "Circle K",
        "name": "Circle K „Kryžkalnis 2“",
        "address": "Dvaro g. 3, Košiai II, 75226",
        "city": "Košiai II",
        "lat": 55.4843351,
        "lon": 22.5879147,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-kretinga-55-8635199-21-2177356",
        "brand": "Circle K",
        "name": "Circle K „Kretinga“",
        "address": "Klaipėdos g. 155, Kretinga, 97156",
        "city": "Kretinga",
        "lat": 55.8635199,
        "lon": 21.2177356,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-kurenai-55-312027-24-7866246",
        "brand": "Circle K",
        "name": "Circle K „Kurėnai“",
        "address": "Ežero g. 7, Kurėnai, 20102",
        "city": "Kurėnai",
        "lat": 55.312027,
        "lon": 24.7866246,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-kursenai-55-9992648-22-9897115",
        "brand": "Circle K",
        "name": "Circle K „Kuršėnai“",
        "address": "Plento g. 1, Kuršėnai, 81115",
        "city": "Kuršėnai",
        "lat": 55.9992648,
        "lon": 22.9897115,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-marijampole-centras-54-557191-23-3540773",
        "brand": "Circle K",
        "name": "Circle K „Marijampolė Centras“",
        "address": "Jono Dailidės g. 10, Marijampolė, 68307",
        "city": "Marijampolė",
        "lat": 54.557191,
        "lon": 23.3540773,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-marijampole-54-5762265-23-3715038",
        "brand": "Circle K",
        "name": "Circle K „Marijampolė“",
        "address": "Kauno g. 130, Marijampolė, 68230",
        "city": "Marijampolė",
        "lat": 54.5762265,
        "lon": 23.3715038,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-garliava-54-8188772-23-8581372",
        "brand": "Circle K",
        "name": "Circle K „Garliava“",
        "address": "Baltijos g. 1, Mastaičiai, 53289",
        "city": "Mastaičiai",
        "lat": 54.8188772,
        "lon": 23.8581372,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-mazeikiai-56-3024538-22-3454238",
        "brand": "Circle K",
        "name": "Circle K „Mažeikiai“",
        "address": "Žemaitijos g. 57, Mažeikiai, 89128",
        "city": "Mažeikiai",
        "lat": 56.3024538,
        "lon": 22.3454238,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-lazdijai-54-2267856-23-5253543",
        "brand": "Circle K",
        "name": "Circle K „Lazdijai“",
        "address": "1, Nekrūnai",
        "city": "Nekrūnai",
        "lat": 54.2267856,
        "lon": 23.5253543,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-palanga-55-9146664-21-0779032",
        "brand": "Circle K",
        "name": "Circle K „Palanga“",
        "address": "Kretingos g. 56, Palanga, 00111",
        "city": "Palanga",
        "lat": 55.9146664,
        "lon": 21.0779032,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-basanaviciaus-55-7174868-24-3712384",
        "brand": "Circle K",
        "name": "Circle K „Basanavičiaus“",
        "address": "J. Basanavičiaus g. 63, Panevėžys, 36204",
        "city": "Panevėžys",
        "lat": 55.7174868,
        "lon": 24.3712384,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-nemuno-55-7286927-24-3389325",
        "brand": "Circle K",
        "name": "Circle K „Nemuno“",
        "address": "Klaipėdos g. 92A, Panevėžys, 37383",
        "city": "Panevėžys",
        "lat": 55.7286927,
        "lon": 24.3389325,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-parkas-55-7317369-24-3424294",
        "brand": "Circle K",
        "name": "Circle K „Parkas“",
        "address": "Parko g. 7A, Panevėžys",
        "city": "Panevėžys",
        "lat": 55.7317369,
        "lon": 24.3424294,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-kryzkalnis-55-4612867-22-693182",
        "brand": "Circle K",
        "name": "Circle K „Kryžkalnis“",
        "address": "5, Pikeliai, 60376",
        "city": "Pikeliai",
        "lat": 55.4612867,
        "lon": 22.693182,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-kavarskas-55-4243052-24-9204947",
        "brand": "Circle K",
        "name": "Circle K „Kavarskas“",
        "address": "Pumpučių g. 25, Pumpučiai, 29260",
        "city": "Pumpučiai",
        "lat": 55.4243052,
        "lon": 24.9204947,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-radviliskis-55-8116756-23-550089",
        "brand": "Circle K",
        "name": "Circle K „Radviliškis“",
        "address": "Gedimino g. 42B, Radviliškis, 82174",
        "city": "Radviliškis",
        "lat": 55.8116756,
        "lon": 23.550089,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-rokiskis-55-9522544-25-5897676",
        "brand": "Circle K",
        "name": "Circle K „Rokiškis“",
        "address": "Respublikos g. 111A, Rokiškis",
        "city": "Rokiškis",
        "lat": 55.9522544,
        "lon": 25.5897676,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-joniskis-56-2585625-23-6218406",
        "brand": "Circle K",
        "name": "Circle K „Joniškis“",
        "address": "Sidabros g. 2A, Satkūnai, 84101",
        "city": "Satkūnai",
        "lat": 56.2585625,
        "lon": 23.6218406,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-vilkaviskis-54-6364068-23-0747794",
        "brand": "Circle K",
        "name": "Circle K „Vilkaviškis“",
        "address": "Vilkaviškio g. 10, Serdokai, 70201",
        "city": "Serdokai",
        "lat": 54.6364068,
        "lon": 23.0747794,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-dubijos-55-9287546-23-2975956",
        "brand": "Circle K",
        "name": "Circle K „Dubijos“",
        "address": "Dubijos g. 20A, Šiauliai, 77207",
        "city": "Šiauliai",
        "lat": 55.9287546,
        "lon": 23.2975956,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-pabaliai-55-9093502-23-3194771",
        "brand": "Circle K",
        "name": "Circle K „Pabaliai“",
        "address": "Pramonės g. 17A, Šiauliai, 78136",
        "city": "Šiauliai",
        "lat": 55.9093502,
        "lon": 23.3194771,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-tilzes-55-9126815-23-2740036",
        "brand": "Circle K",
        "name": "Circle K „Tilžės“",
        "address": "Tilžės g. 25, Šiauliai, 78229",
        "city": "Šiauliai",
        "lat": 55.9126815,
        "lon": 23.2740036,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-1-2-3-ezeras-55-9248038-23-3340344",
        "brand": "Circle K",
        "name": "Circle K 1-2-3 Ežeras",
        "address": "Vilniaus g. 62, Šiauliai, 76251",
        "city": "Šiauliai",
        "lat": 55.9248038,
        "lon": 23.3340344,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-aplinkkelis-ii-55-6724543-24-3365033",
        "brand": "Circle K",
        "name": "Circle K „Aplinkkelis II“",
        "address": "Panevėžio aplinkl. 20, Šilagalys, 38417",
        "city": "Šilagalys",
        "lat": 55.6724543,
        "lon": 24.3365033,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-automatas-taurage-55-266997-22-3098059",
        "brand": "Circle K",
        "name": "Circle K „Automatas Tauragė“",
        "address": "Dariaus ir Girėno g. 83A, Tauragė, 72192",
        "city": "Tauragė",
        "lat": 55.266997,
        "lon": 22.3098059,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-taurage-55-2482941-22-3030291",
        "brand": "Circle K",
        "name": "Circle K „Tauragė“",
        "address": "Gedimino g. 47, Tauragė, 72294",
        "city": "Tauragė",
        "lat": 55.2482941,
        "lon": 22.3030291,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-telsiai-55-9771178-22-26512",
        "brand": "Circle K",
        "name": "Circle K „Telšiai“",
        "address": "Luokės g. 70, Telšiai, 87128",
        "city": "Telšiai",
        "lat": 55.9771178,
        "lon": 22.26512,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-plunge-55-9388039-21-8801458",
        "brand": "Circle K",
        "name": "Circle K „Plungė“",
        "address": "Pramogų g. 4, Truikiai, 90110",
        "city": "Truikiai",
        "lat": 55.9388039,
        "lon": 21.8801458,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-aplinkkelis-55-8104729-24-3688142",
        "brand": "Circle K",
        "name": "Circle K „Aplinkkelis“",
        "address": "Baltijos Kelio g. 33, Ūta, 38413",
        "city": "Ūta",
        "lat": 55.8104729,
        "lon": 24.3688142,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-utena-i-55-5050028-25-6209441",
        "brand": "Circle K",
        "name": "Circle K „Utena“ I",
        "address": "J. Basanavičiaus g. 108A, Utena, 28214",
        "city": "Utena",
        "lat": 55.5050028,
        "lon": 25.6209441,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-utena-ii-55-4957997-25-5830461",
        "brand": "Circle K",
        "name": "Circle K „Utena“ II",
        "address": "J. Basanavičiaus g. 3A, Utena, 28134",
        "city": "Utena",
        "lat": 55.4957997,
        "lon": 25.5830461,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-54-7514091-25-2663978",
        "brand": "Circle K",
        "name": "Circle K",
        "address": "Geležinio Vilko g. 24, Vilnius, 08412",
        "city": "Vilnius",
        "lat": 54.7514091,
        "lon": 25.2663978,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-baltupiai-54-7359499-25-2654451",
        "brand": "Circle K",
        "name": "Circle K „Baltupiai“",
        "address": "Baltupio g. 10, Vilnius, 08303",
        "city": "Vilnius",
        "lat": 54.7359499,
        "lon": 25.2654451,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-fabijoniskes-54-7202224-25-2462981",
        "brand": "Circle K",
        "name": "Circle K „Fabijoniškės“",
        "address": "Ukmergės g. 231, Vilnius, 07156",
        "city": "Vilnius",
        "lat": 54.7202224,
        "lon": 25.2462981,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-gariunai-54-658914-25-161129",
        "brand": "Circle K",
        "name": "Circle K „Gariūnai“",
        "address": "Gariūnų g. 45, Vilnius",
        "city": "Vilnius",
        "lat": 54.658914,
        "lon": 25.161129,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-karoliniskes-54-6953159-25-2182689",
        "brand": "Circle K",
        "name": "Circle K „Karoliniškės“",
        "address": "A. P. Kavoliuko g. 32A, Vilnius, 04329",
        "city": "Vilnius",
        "lat": 54.6953159,
        "lon": 25.2182689,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-oro-uostas-54-6515142-25-269463",
        "brand": "Circle K",
        "name": "Circle K „Oro uostas“",
        "address": "Eišiškių pl. 11, Vilnius, 02184",
        "city": "Vilnius",
        "lat": 54.6515142,
        "lon": 25.269463,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-salia-parlamento-54-6941914-25-2634259",
        "brand": "Circle K",
        "name": "Circle K „Šalia Parlamento“",
        "address": "A. Goštauto g. 13, Vilnius, 01108",
        "city": "Vilnius",
        "lat": 54.6941914,
        "lon": 25.2634259,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-seskines-kalnas-ii-54-7028361-25-2639154",
        "brand": "Circle K",
        "name": "Circle K „Šeškinės kalnas II“",
        "address": "Geležinio Vilko g. 4, Vilnius, 08104",
        "city": "Vilnius",
        "lat": 54.7028361,
        "lon": 25.2639154,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-seskines-kalnas-54-7023542-25-2649591",
        "brand": "Circle K",
        "name": "Circle K „Šeškinės kalnas“",
        "address": "Geležinio Vilko g. 39, Vilnius, 08104",
        "city": "Vilnius",
        "lat": 54.7023542,
        "lon": 25.2649591,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-talino-g-54-7133564-25-2094364",
        "brand": "Circle K",
        "name": "Circle K „Talino g.“",
        "address": "Talino g. 2B, Vilnius, 05200",
        "city": "Vilnius",
        "lat": 54.7133564,
        "lon": 25.2094364,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-tukstantmetis-54-6586666-25-2666141",
        "brand": "Circle K",
        "name": "Circle K „Tūkstantmetis“",
        "address": "Prūsų g. 26A, Vilnius, 02154",
        "city": "Vilnius",
        "lat": 54.6586666,
        "lon": 25.2666141,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-ukmerges-54-7305638-25-2390191",
        "brand": "Circle K",
        "name": "Circle K „Ukmergės“",
        "address": "P. Žadeikos g. 1A, Vilnius, 06319",
        "city": "Vilnius",
        "lat": 54.7305638,
        "lon": 25.2390191,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-verkiai-54-7155404-25-2910226",
        "brand": "Circle K",
        "name": "Circle K „Verkiai“",
        "address": "Kareivių g. 3, Vilnius, 08221",
        "city": "Vilnius",
        "lat": 54.7155404,
        "lon": 25.2910226,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-vilkpede-i-54-6626698-25-2347375",
        "brand": "Circle K",
        "name": "Circle K „Vilkpėdė I“",
        "address": "Savanorių pr. 119A, Vilnius, 03150",
        "city": "Vilnius",
        "lat": 54.6626698,
        "lon": 25.2347375,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-vilkpede-ii-54-6618437-25-2354443",
        "brand": "Circle K",
        "name": "Circle K „Vilkpėdė II“",
        "address": "Savanorių pr. 118, Vilnius, 03153",
        "city": "Vilnius",
        "lat": 54.6618437,
        "lon": 25.2354443,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-vingis-54-6710006-25-2366237",
        "brand": "Circle K",
        "name": "Circle K „Vingis“",
        "address": "Geležinio Vilko g. 2A, Vilnius, 03150",
        "city": "Vilnius",
        "lat": 54.6710006,
        "lon": 25.2366237,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-virsuliskes-54-7091985-25-228042",
        "brand": "Circle K",
        "name": "Circle K „Viršuliškės“",
        "address": "Laisvės pr. 43C, Vilnius",
        "city": "Vilnius",
        "lat": 54.7091985,
        "lon": 25.228042,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-voke-54-622939-25-1102914",
        "brand": "Circle K",
        "name": "Circle K „Vokė“",
        "address": "J. Tiškevičiaus g. 24, Vilnius, 02231",
        "city": "Vilnius",
        "lat": 54.622939,
        "lon": 25.1102914,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-zirmunai-54-718581-25-3006212",
        "brand": "Circle K",
        "name": "Circle K „Žirmūnai“",
        "address": "Kareivių g. 13, Vilnius, 09109",
        "city": "Vilnius",
        "lat": 54.718581,
        "lon": 25.3006212,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-zirmunu-tiltas-54-6950788-25-298113",
        "brand": "Circle K",
        "name": "Circle K „Žirmūnų tiltas“",
        "address": "Sporto g. 16A, Vilnius, 09200",
        "city": "Vilnius",
        "lat": 54.6950788,
        "lon": 25.298113,
        "prices": {}
    },
    {
        "id": "circle-k-circle-k-1-2-3-54-6710312-25-1921158",
        "brand": "Circle K",
        "name": "Circle K 1-2-3",
        "address": "Oslo g. 12, Vilnius, 04123",
        "city": "Vilnius",
        "lat": 54.6710312,
        "lon": 25.1921158,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-582934-23-3709915",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Aleksandravas",
        "city": "Aleksandravas",
        "lat": 54.582934,
        "lon": 23.3709915,
        "prices": {}
    },
    {
        "id": "orlen-orlen-55-7078112-21-2457385",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Vilniaus pl. 13, Jakai, 96322",
        "city": "Jakai",
        "lat": 55.7078112,
        "lon": 21.2457385,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-7907147-24-6697012",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Žilvičių g. 1A, Kakliniškės",
        "city": "Kakliniškės",
        "lat": 54.7907147,
        "lon": 24.6697012,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-9158049-23-9842047",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Pramonės pr. 37, Kaunas, 51272",
        "city": "Kaunas",
        "lat": 54.9158049,
        "lon": 23.9842047,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-86734-23-8872981",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Veiverių g. 148B, Kaunas",
        "city": "Kaunas",
        "lat": 54.86734,
        "lon": 23.8872981,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-9138215-23-9068411",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Varnių g. 50, Kaunas, 48400",
        "city": "Kaunas",
        "lat": 54.9138215,
        "lon": 23.9068411,
        "prices": {}
    },
    {
        "id": "orlen-orlen-55-6681613-21-2086485",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Šilutės pl. 94, Klaipėda",
        "city": "Klaipėda",
        "lat": 55.6681613,
        "lon": 21.2086485,
        "prices": {}
    },
    {
        "id": "orlen-orlen-55-6938667-21-1402705",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Minijos g. 44, Klaipėda, 91197",
        "city": "Klaipėda",
        "lat": 55.6938667,
        "lon": 21.1402705,
        "prices": {}
    },
    {
        "id": "orlen-orlen-lietuva-55-6985727-21-1673283",
        "brand": "ORLEN",
        "name": "Orlen - Lietuva",
        "address": "Šilutės pl. 26A, Klaipėda",
        "city": "Klaipėda",
        "lat": 55.6985727,
        "lon": 21.1673283,
        "prices": {}
    },
    {
        "id": "orlen-orlen-55-4645042-22-6846516",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "2, Kryžkalnis",
        "city": "Kryžkalnis",
        "lat": 55.4645042,
        "lon": 22.6846516,
        "prices": {}
    },
    {
        "id": "orlen-orlen-55-5686092-22-1774596",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "6, Kuodaičiai",
        "city": "Kuodaičiai",
        "lat": 55.5686092,
        "lon": 22.1774596,
        "prices": {}
    },
    {
        "id": "orlen-orlen-56-3144578-22-3110051",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Skuodo g. 14, Mažeikiai, 89100",
        "city": "Mažeikiai",
        "lat": 56.3144578,
        "lon": 22.3110051,
        "prices": {}
    },
    {
        "id": "orlen-orlen-56-302047-22-3424428",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Žemaitijos g. 42, Mažeikiai, 89191",
        "city": "Mažeikiai",
        "lat": 56.302047,
        "lon": 22.3424428,
        "prices": {}
    },
    {
        "id": "orlen-orlen-55-7338434-24-2635593",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Šiaulių g. 50, Nausodė, 38366",
        "city": "Nausodė",
        "lat": 55.7338434,
        "lon": 24.2635593,
        "prices": {}
    },
    {
        "id": "orlen-orlen-55-7317633-24-3031779",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Klaipėdos g. 162D, Panevėžys, 37372",
        "city": "Panevėžys",
        "lat": 55.7317633,
        "lon": 24.3031779,
        "prices": {}
    },
    {
        "id": "orlen-orlen-senamiescio-g-115-panevezys-35114-55-7482114-24-3908576",
        "brand": "ORLEN",
        "name": "ORLEN Senamiesčio g. 115, Panevėžys, 35114",
        "address": "Senamiesčio g. 115, Panevėžys, 35114",
        "city": "Panevėžys",
        "lat": 55.7482114,
        "lon": 24.3908576,
        "prices": {}
    },
    {
        "id": "orlen-orlen-55-4616207-22-6957891",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "8, Pikeliai",
        "city": "Pikeliai",
        "lat": 55.4616207,
        "lon": 22.6957891,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-8886275-23-8185164",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Beržų g. 2M, Ringaudai",
        "city": "Ringaudai",
        "lat": 54.8886275,
        "lon": 23.8185164,
        "prices": {}
    },
    {
        "id": "orlen-orlen-55-9136087-23-3368761",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Serbentų g. 82, Šiauliai, 77118",
        "city": "Šiauliai",
        "lat": 55.9136087,
        "lon": 23.3368761,
        "prices": {}
    },
    {
        "id": "orlen-orlen-55-2442624-22-303731",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Gedimino g. 46, Tauragė",
        "city": "Tauragė",
        "lat": 55.2442624,
        "lon": 22.303731,
        "prices": {}
    },
    {
        "id": "orlen-orlen-telšiai",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Plungės g. 33, Telšiai",
        "city": "Telšiai",
        "lat": 55.979240,
        "lon": 22.226684,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-578844-24-1706387",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Alytaus g. 2, Verbyliškės, 59431",
        "city": "Verbyliškės",
        "lat": 54.578844,
        "lon": 24.1706387,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-7280617-25-3270106",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "O. Milašiaus g. 31, Vilnius, 10102",
        "city": "Vilnius",
        "lat": 54.7280617,
        "lon": 25.3270106,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-7369212-25-2320308",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Ukmergės g. 319, Vilnius, 06305",
        "city": "Vilnius",
        "lat": 54.7369212,
        "lon": 25.2320308,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-695998-25-3001004",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Žirmūnų g. 1T, Vilnius",
        "city": "Vilnius",
        "lat": 54.695998,
        "lon": 25.3001004,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-6629611-25-3423811",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Juodasis kel. 32, Vilnius, 11307",
        "city": "Vilnius",
        "lat": 54.6629611,
        "lon": 25.3423811,
        "prices": {}
    },
    {
        "id": "orlen-orlen-54-8159618-24-4334433",
        "brand": "ORLEN",
        "name": "Orlen",
        "address": "Kauno pl. 6, Žiežmariai",
        "city": "Žiežmariai",
        "lat": 54.8159618,
        "lon": 24.4334433,
        "prices": {}
    },
    {
        "id": "viada-viada-54-4140218-24-0101812",
        "brand": "Viada",
        "name": "Viada",
        "address": "Naujoji g. 27, Alytus, 62175",
        "city": "Alytus",
        "lat": 54.4140218,
        "lon": 24.0101812,
        "prices": {}
    },
    {
        "id": "viada-viada-54-3847534-24-0499915",
        "brand": "Viada",
        "name": "Viada",
        "address": "Ulonų g. 33B, Alytus",
        "city": "Alytus",
        "lat": 54.3847534,
        "lon": 24.0499915,
        "prices": {}
    },
    {
        "id": "viada-viada-55-522041-25-0863648",
        "brand": "Viada",
        "name": "Viada",
        "address": "A. Vienuolio g. 34, Anykščiai, 29149",
        "city": "Anykščiai",
        "lat": 55.522041,
        "lon": 25.0863648,
        "prices": {}
    },
    {
        "id": "viada-viada-55-5413264-25-1349412",
        "brand": "Viada",
        "name": "Viada",
        "address": "Piliakalnio g. 9, Anykščiai",
        "city": "Anykščiai",
        "lat": 55.5413264,
        "lon": 25.1349412,
        "prices": {}
    },
    {
        "id": "viada-viada-55-8818446-23-2052671",
        "brand": "Viada",
        "name": "Viada",
        "address": "Ilgoji g. 1, Aukštelkė, 80183",
        "city": "Aukštelkė",
        "lat": 55.8818446,
        "lon": 23.2052671,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7017104-25-009811",
        "brand": "Viada",
        "name": "Viada",
        "address": "Logistikos g. 9, Aukštieji Semeniukai",
        "city": "Aukštieji Semeniukai",
        "lat": 54.7017104,
        "lon": 25.009811,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6981109-23-5173562",
        "brand": "Viada",
        "name": "Viada",
        "address": "Marijampolės g. 53, Ąžuolų Būda, 69452",
        "city": "Ąžuolų Būda",
        "lat": 54.6981109,
        "lon": 23.5173562,
        "prices": {}
    },
    {
        "id": "viada-viada-56-1887612-24-7384429",
        "brand": "Viada",
        "name": "Viada",
        "address": "Plento g. 37, Biržai, 41127",
        "city": "Biržai",
        "lat": 56.1887612,
        "lon": 24.7384429,
        "prices": {}
    },
    {
        "id": "viada-viada-56-2013303-24-7490217",
        "brand": "Viada",
        "name": "Viada",
        "address": "Parodos g. 2, Biržai, 41136",
        "city": "Biržai",
        "lat": 56.2013303,
        "lon": 24.7490217,
        "prices": {}
    },
    {
        "id": "viada-viada-56-2019312-24-7377964",
        "brand": "Viada",
        "name": "Viada",
        "address": "Pasvalio g. 1B, Biržai",
        "city": "Biržai",
        "lat": 56.2019312,
        "lon": 24.7377964,
        "prices": {}
    },
    {
        "id": "viada-viada-56-0421867-24-3781981",
        "brand": "Viada",
        "name": "Viada",
        "address": "1, Brazdigala",
        "city": "Brazdigala",
        "lat": 56.0421867,
        "lon": 24.3781981,
        "prices": {}
    },
    {
        "id": "viada-viada-55-374734-23-8808049",
        "brand": "Viada",
        "name": "Viada",
        "address": "Tilto g. 2A, Dotnuva",
        "city": "Dotnuva",
        "lat": 55.374734,
        "lon": 23.8808049,
        "prices": {}
    },
    {
        "id": "viada-viada-55-2691205-24-8101186",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vytauto g. 131, Dukstyna, 20185",
        "city": "Dukstyna",
        "lat": 55.2691205,
        "lon": 24.8101186,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7845492-24-654228",
        "brand": "Viada",
        "name": "Viada",
        "address": "Elektrinės g. 6, Elektrėnai",
        "city": "Elektrėnai",
        "lat": 54.7845492,
        "lon": 24.654228,
        "prices": {}
    },
    {
        "id": "viada-viada-55-7321688-21-3761952",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vilniaus pl. 65, Gargždai",
        "city": "Gargždai",
        "lat": 55.7321688,
        "lon": 21.3761952,
        "prices": {}
    },
    {
        "id": "viada-viada-55-4778277-25-581565",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vyturio g. 2, Gediminas, 28125",
        "city": "Gediminas",
        "lat": 55.4778277,
        "lon": 25.581565,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9591082-23-8642584",
        "brand": "Viada",
        "name": "Viada",
        "address": "Automagistralės g. 4, Giraitė, 54310",
        "city": "Giraitė",
        "lat": 54.9591082,
        "lon": 23.8642584,
        "prices": {}
    },
    {
        "id": "viada-viada-55-2146516-25-4379884",
        "brand": "Viada",
        "name": "Viada",
        "address": "Utenos g. 16, Gojus",
        "city": "Gojus",
        "lat": 55.2146516,
        "lon": 25.4379884,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7139071-23-6498047",
        "brand": "Viada",
        "name": "Viada",
        "address": "11, Grigaliūnai",
        "city": "Grigaliūnai",
        "lat": 54.7139071,
        "lon": 23.6498047,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6691776-25-1048685",
        "brand": "Viada",
        "name": "Viada",
        "address": "Kovo 11-osios g. 75, Grigiškės",
        "city": "Grigiškės",
        "lat": 54.6691776,
        "lon": 25.1048685,
        "prices": {}
    },
    {
        "id": "viada-baltic-petroleum-55-0991092-24-3159523",
        "brand": "Viada",
        "name": "Baltic Petroleum",
        "address": "Plento g. 24, Gudžioniai, 55462",
        "city": "Gudžioniai",
        "lat": 55.0991092,
        "lon": 24.3159523,
        "prices": {}
    },
    {
        "id": "viada-viada-54-774143-23-8896161",
        "brand": "Viada",
        "name": "Viada",
        "address": "Prienų g. 22, Ilgakiemis, 53288",
        "city": "Ilgakiemis",
        "lat": 54.774143,
        "lon": 23.8896161,
        "prices": {}
    },
    {
        "id": "viada-viada-54-439594-25-3273439",
        "brand": "Viada",
        "name": "Viada",
        "address": "Lydos g. 13, Jašiūnai, 30132",
        "city": "Jašiūnai",
        "lat": 54.439594,
        "lon": 25.3273439,
        "prices": {}
    },
    {
        "id": "viada-viada-55-0937252-24-2827556",
        "brand": "Viada",
        "name": "Viada",
        "address": "Darbininkų g. 4D, Jonava",
        "city": "Jonava",
        "lat": 55.0937252,
        "lon": 24.2827556,
        "prices": {}
    },
    {
        "id": "viada-viada-56-2246233-23-6010978",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vilniaus g. 51, Joniškis",
        "city": "Joniškis",
        "lat": 56.2246233,
        "lon": 23.6010978,
        "prices": {}
    },
    {
        "id": "viada-viada-55-7178081-26-2137463",
        "brand": "Viada",
        "name": "Viada",
        "address": "2, Juodalaukiai",
        "city": "Juodalaukiai",
        "lat": 55.7178081,
        "lon": 26.2137463,
        "prices": {}
    },
    {
        "id": "viada-viada-54-8550869-24-4417262",
        "brand": "Viada",
        "name": "Viada",
        "address": "Gedimino g. 135, Kaišiadorys, 56173",
        "city": "Kaišiadorys",
        "lat": 54.8550869,
        "lon": 24.4417262,
        "prices": {}
    },
    {
        "id": "viada-viada-55-2551139-25-9905688",
        "brand": "Viada",
        "name": "Viada",
        "address": "Utenos g. 1, Kaltanėnai, 18239",
        "city": "Kaltanėnai",
        "lat": 55.2551139,
        "lon": 25.9905688,
        "prices": {}
    },
    {
        "id": "viada-viada-54-4244522-23-2319501",
        "brand": "Viada",
        "name": "Viada",
        "address": "Dariaus ir Girėno g. 81, Kalvarija, 69219",
        "city": "Kalvarija",
        "lat": 54.4244522,
        "lon": 23.2319501,
        "prices": {}
    },
    {
        "id": "viada-viada-54-8425457-23-8496814",
        "brand": "Viada",
        "name": "Viada",
        "address": "Baltijos g. 41, Kampiškiai",
        "city": "Kampiškiai",
        "lat": 54.8425457,
        "lon": 23.8496814,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9114025-24-0210519",
        "brand": "Viada",
        "name": "Viada",
        "address": "Biruliškių g. 18A, Kaunas",
        "city": "Kaunas",
        "lat": 54.9114025,
        "lon": 24.0210519,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9272209-23-9747863",
        "brand": "Viada",
        "name": "Viada",
        "address": "Pramonės pr. 44, Kaunas, 50302",
        "city": "Kaunas",
        "lat": 54.9272209,
        "lon": 23.9747863,
        "prices": {}
    },
    {
        "id": "viada-viada-54-8809124-24-0097867",
        "brand": "Viada",
        "name": "Viada",
        "address": "T. Masiulio g. 22B, Kaunas",
        "city": "Kaunas",
        "lat": 54.8809124,
        "lon": 24.0097867,
        "prices": {}
    },
    {
        "id": "viada-viada-54-883335-23-8936433",
        "brand": "Viada",
        "name": "Viada",
        "address": "Veiverių g. 124B, Kaunas",
        "city": "Kaunas",
        "lat": 54.883335,
        "lon": 23.8936433,
        "prices": {}
    },
    {
        "id": "viada-viada-54-8787342-23-9342999",
        "brand": "Viada",
        "name": "Viada",
        "address": "A. Juozapavičiaus pr. 92, Kaunas, 45210",
        "city": "Kaunas",
        "lat": 54.8787342,
        "lon": 23.9342999,
        "prices": {}
    },
    {
        "id": "viada-viada-54-924924-23-9423227",
        "brand": "Viada",
        "name": "Viada",
        "address": "P. Lukšio g. 66A, Kaunas",
        "city": "Kaunas",
        "lat": 54.924924,
        "lon": 23.9423227,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9334544-23-9683722",
        "brand": "Viada",
        "name": "Viada",
        "address": "Islandijos pl. 61, Kaunas",
        "city": "Kaunas",
        "lat": 54.9334544,
        "lon": 23.9683722,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9180087-23-8736664",
        "brand": "Viada",
        "name": "Viada",
        "address": "Baltijos g. 90B, Kaunas, 47133",
        "city": "Kaunas",
        "lat": 54.9180087,
        "lon": 23.8736664,
        "prices": {}
    },
    {
        "id": "viada-viada-54-8551053-24-0131235",
        "brand": "Viada",
        "name": "Viada",
        "address": "Didžioji g. 84, Kaunas, 45462",
        "city": "Kaunas",
        "lat": 54.8551053,
        "lon": 24.0131235,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9176848-23-8630657",
        "brand": "Viada",
        "name": "Viada",
        "address": "Miežėnų g. 18, Kaunas, 47115",
        "city": "Kaunas",
        "lat": 54.9176848,
        "lon": 23.8630657,
        "prices": {}
    },
    {
        "id": "viada-viada-54-8495193-23-9670945",
        "brand": "Viada",
        "name": "Viada",
        "address": "Marijampolės pl. 29, Kaunas, 46147",
        "city": "Kaunas",
        "lat": 54.8495193,
        "lon": 23.9670945,
        "prices": {}
    },
    {
        "id": "viada-viada-54-8875335-23-9211443",
        "brand": "Viada",
        "name": "Viada",
        "address": "Karaliaus Mindaugo pr. 54, Kaunas, 44351",
        "city": "Kaunas",
        "lat": 54.8875335,
        "lon": 23.9211443,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9182237-24-0396678",
        "brand": "Viada",
        "name": "Viada",
        "address": "Ateities pl. 37A, Kaunas, 52119",
        "city": "Kaunas",
        "lat": 54.9182237,
        "lon": 24.0396678,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9213912-23-8105362",
        "brand": "Viada",
        "name": "Viada",
        "address": "Raudondvario pl. 288, Kaunas, 47164",
        "city": "Kaunas",
        "lat": 54.9213912,
        "lon": 23.8105362,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9271996-24-0430425",
        "brand": "Viada",
        "name": "Viada",
        "address": "Ateities pl. 105, Kaunas",
        "city": "Kaunas",
        "lat": 54.9271996,
        "lon": 24.0430425,
        "prices": {}
    },
    {
        "id": "viada-viada-54-8975525-23-95835",
        "brand": "Viada",
        "name": "Viada",
        "address": "K. Baršausko g. 64, Kaunas, 44410",
        "city": "Kaunas",
        "lat": 54.8975525,
        "lon": 23.95835,
        "prices": {}
    },
    {
        "id": "viada-viada-54-92009-23-94876",
        "brand": "Viada",
        "name": "Viada",
        "address": "Statybininkų g. 3A, Kaunas",
        "city": "Kaunas",
        "lat": 54.92009,
        "lon": 23.94876,
        "prices": {}
    },
    {
        "id": "viada-viada-54-8664488-23-8894647",
        "brand": "Viada",
        "name": "Viada",
        "address": "Veiverių g. 117, Kaunas, 46386",
        "city": "Kaunas",
        "lat": 54.8664488,
        "lon": 23.8894647,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9038355-23-8353142",
        "brand": "Viada",
        "name": "Viada",
        "address": "Marvelės g. 132, Kaunas, 46230",
        "city": "Kaunas",
        "lat": 54.9038355,
        "lon": 23.8353142,
        "prices": {}
    },
    {
        "id": "viada-viada-55-8565394-25-1735326",
        "brand": "Viada",
        "name": "Viada",
        "address": "1A, Kereliai",
        "city": "Kereliai",
        "lat": 55.8565394,
        "lon": 25.1735326,
        "prices": {}
    },
    {
        "id": "viada-viada-55-7192159-21-1411365",
        "brand": "Viada",
        "name": "Viada",
        "address": "Priestočio g. 28, Klaipėda, 92228",
        "city": "Klaipėda",
        "lat": 55.7192159,
        "lon": 21.1411365,
        "prices": {}
    },
    {
        "id": "viada-viada-55-7538812-21-1313388",
        "brand": "Viada",
        "name": "Viada",
        "address": "Liepojos g. 242, Klaipėda, 92330",
        "city": "Klaipėda",
        "lat": 55.7538812,
        "lon": 21.1313388,
        "prices": {}
    },
    {
        "id": "viada-viada-55-6817379-21-1851775",
        "brand": "Viada",
        "name": "Viada",
        "address": "Šilutės pl. 52, Klaipėda",
        "city": "Klaipėda",
        "lat": 55.6817379,
        "lon": 21.1851775,
        "prices": {}
    },
    {
        "id": "viada-viada-55-6832071-21-1604564",
        "brand": "Viada",
        "name": "Viada",
        "address": "Taikos pr. 70A, Klaipėda",
        "city": "Klaipėda",
        "lat": 55.6832071,
        "lon": 21.1604564,
        "prices": {}
    },
    {
        "id": "viada-viada-55-6751972-21-1530337",
        "brand": "Viada",
        "name": "Viada",
        "address": "Nemuno g. 139, Klaipėda",
        "city": "Klaipėda",
        "lat": 55.6751972,
        "lon": 21.1530337,
        "prices": {}
    },
    {
        "id": "viada-viada-55-8905707-21-2782712",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vytauto g. 163, Kretinga, 97159",
        "city": "Kretinga",
        "lat": 55.8905707,
        "lon": 21.2782712,
        "prices": {}
    },
    {
        "id": "viada-viada-55-8275247-21-1849852",
        "brand": "Viada",
        "name": "Viada",
        "address": "Klaipėdos g. 1A, Kretingalė",
        "city": "Kretingalė",
        "lat": 55.8275247,
        "lon": 21.1849852,
        "prices": {}
    },
    {
        "id": "viada-viada-sodziaus-g-kretingsodis-55-8959396-21-2213978",
        "brand": "Viada",
        "name": "Viada Sodžiaus g., Kretingsodis",
        "address": "Sodžiaus g., Kretingsodis",
        "city": "Kretingsodis",
        "lat": 55.8959396,
        "lon": 21.2213978,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9591245-23-8668279",
        "brand": "Viada",
        "name": "Viada",
        "address": "Verslo g. 13A, Kumpiai, 54311",
        "city": "Kumpiai",
        "lat": 54.9591245,
        "lon": 23.8668279,
        "prices": {}
    },
    {
        "id": "viada-viada-55-8445728-24-9789866",
        "brand": "Viada",
        "name": "Viada",
        "address": "Pergalės g. 15, Kupiškis, 40109",
        "city": "Kupiškis",
        "lat": 55.8445728,
        "lon": 24.9789866,
        "prices": {}
    },
    {
        "id": "viada-viada-55-9998788-22-9476559",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vilniaus g. 38A, Kuršėnai, 81136",
        "city": "Kuršėnai",
        "lat": 55.9998788,
        "lon": 22.9476559,
        "prices": {}
    },
    {
        "id": "viada-viada-55-6181537-22-9016969",
        "brand": "Viada",
        "name": "Viada",
        "address": "1, Kuršukai",
        "city": "Kuršukai",
        "lat": 55.6181537,
        "lon": 22.9016969,
        "prices": {}
    },
    {
        "id": "viada-viada-55-9790907-23-1362261",
        "brand": "Viada",
        "name": "Viada",
        "address": "Draugystės g. 2, Kužiai, 80269",
        "city": "Kužiai",
        "lat": 55.9790907,
        "lon": 23.1362261,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6589893-23-9470417",
        "brand": "Viada",
        "name": "Viada",
        "address": "Kauno pl. 40, Mačiūnai, 59157",
        "city": "Mačiūnai",
        "lat": 54.6589893,
        "lon": 23.9470417,
        "prices": {}
    },
    {
        "id": "viada-viada-54-5677565-23-3393284",
        "brand": "Viada",
        "name": "Viada",
        "address": "J. Ambrazevičiaus-Brazaičio g. 2, Marijampolė, 68160",
        "city": "Marijampolė",
        "lat": 54.5677565,
        "lon": 23.3393284,
        "prices": {}
    },
    {
        "id": "viada-viada-54-5543671-23-3623616",
        "brand": "Viada",
        "name": "Viada",
        "address": "Geležinkelio g. 5, Marijampolė, 68304",
        "city": "Marijampolė",
        "lat": 54.5543671,
        "lon": 23.3623616,
        "prices": {}
    },
    {
        "id": "viada-viada-56-3159021-22-302462",
        "brand": "Viada",
        "name": "Viada",
        "address": "Montuotojų g. 2A, Mažeikiai",
        "city": "Mažeikiai",
        "lat": 56.3159021,
        "lon": 22.302462,
        "prices": {}
    },
    {
        "id": "viada-viada-56-3004071-22-3606699",
        "brand": "Viada",
        "name": "Viada",
        "address": "Žemaitijos g. 75, Mažeikiai, 89238",
        "city": "Mažeikiai",
        "lat": 56.3004071,
        "lon": 22.3606699,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9751047-25-7448834",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vilniaus g. 116B, Pabradė",
        "city": "Pabradė",
        "lat": 54.9751047,
        "lon": 25.7448834,
        "prices": {}
    },
    {
        "id": "viada-viada-55-9804516-23-8579856",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vytauto Didžiojo g. 98, Pakruojis, 83128",
        "city": "Pakruojis",
        "lat": 55.9804516,
        "lon": 23.8579856,
        "prices": {}
    },
    {
        "id": "viada-viada-55-70908-24-3733592",
        "brand": "Viada",
        "name": "Viada",
        "address": "Ramygalos g. 186G, Panevėžys",
        "city": "Panevėžys",
        "lat": 55.70908,
        "lon": 24.3733592,
        "prices": {}
    },
    {
        "id": "viada-viada-55-7368508-24-3871858",
        "brand": "Viada",
        "name": "Viada",
        "address": "Venslaviškio g. 16, Panevėžys",
        "city": "Panevėžys",
        "lat": 55.7368508,
        "lon": 24.3871858,
        "prices": {}
    },
    {
        "id": "viada-viada-55-7485823-24-3932637",
        "brand": "Viada",
        "name": "Viada",
        "address": "Senamiesčio g. 116A, Panevėžys, 35115",
        "city": "Panevėžys",
        "lat": 55.7485823,
        "lon": 24.3932637,
        "prices": {}
    },
    {
        "id": "viada-viada-55-7388587-24-3101356",
        "brand": "Viada",
        "name": "Viada",
        "address": "J. Janonio g. 28A, Panevėžys",
        "city": "Panevėžys",
        "lat": 55.7388587,
        "lon": 24.3101356,
        "prices": {}
    },
    {
        "id": "viada-viada-55-7143963-24-3354086",
        "brand": "Viada",
        "name": "Viada",
        "address": "Navadolio g. 29, Panevėžys, 36252",
        "city": "Panevėžys",
        "lat": 55.7143963,
        "lon": 24.3354086,
        "prices": {}
    },
    {
        "id": "viada-viada-56-0559384-24-407185",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vilniaus g. 50, Pasvalys, 39177",
        "city": "Pasvalys",
        "lat": 56.0559384,
        "lon": 24.407185,
        "prices": {}
    },
    {
        "id": "viada-viada-54-3398509-23-1630629",
        "brand": "Viada",
        "name": "Viada",
        "address": "Muitinės g. 35, Pelucmurgiai",
        "city": "Pelucmurgiai",
        "lat": 54.3398509,
        "lon": 23.1630629,
        "prices": {}
    },
    {
        "id": "viada-viada-55-9030779-21-8301663",
        "brand": "Viada",
        "name": "Viada",
        "address": "J. Tumo-Vaižganto g. 102, Plungė, 90142",
        "city": "Plungė",
        "lat": 55.9030779,
        "lon": 21.8301663,
        "prices": {}
    },
    {
        "id": "viada-viada-55-8982917-21-8398639",
        "brand": "Viada",
        "name": "Viada",
        "address": "Žaltakalnio g. 10, Plungė, 90143",
        "city": "Plungė",
        "lat": 55.8982917,
        "lon": 21.8398639,
        "prices": {}
    },
    {
        "id": "viada-viada-55-5211616-24-3126492",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vienkiemio g. 1B, Ramygala",
        "city": "Ramygala",
        "lat": 55.5211616,
        "lon": 24.3126492,
        "prices": {}
    },
    {
        "id": "viada-viada-55-9341832-25-5856994",
        "brand": "Viada",
        "name": "Viada",
        "address": "Žemaitės g. 2C, Rokiškis",
        "city": "Rokiškis",
        "lat": 55.9341832,
        "lon": 25.5856994,
        "prices": {}
    },
    {
        "id": "viada-viada-55-9444282-25-5855631",
        "brand": "Viada",
        "name": "Viada",
        "address": "Panevėžio g. 5, Rokiškis, 42163",
        "city": "Rokiškis",
        "lat": 55.9444282,
        "lon": 25.5855631,
        "prices": {}
    },
    {
        "id": "viada-viada-56-2700097-21-5471475",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vilniaus g. 50, Skuodas, 98119",
        "city": "Skuodas",
        "lat": 56.2700097,
        "lon": 21.5471475,
        "prices": {}
    },
    {
        "id": "viada-viada-55-7044393-21-2216132",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vilniaus pl. 6, Sudmantai, 96327",
        "city": "Sudmantai",
        "lat": 55.7044393,
        "lon": 21.2216132,
        "prices": {}
    },
    {
        "id": "viada-viada-55-9441116-23-3314036",
        "brand": "Viada",
        "name": "Viada",
        "address": "Tilžės g. 274, Šiauliai, 76201",
        "city": "Šiauliai",
        "lat": 55.9441116,
        "lon": 23.3314036,
        "prices": {}
    },
    {
        "id": "viada-viada-55-9225032-23-3579554",
        "brand": "Viada",
        "name": "Viada",
        "address": "Užmiesčio g. 2, Šiauliai, 76273",
        "city": "Šiauliai",
        "lat": 55.9225032,
        "lon": 23.3579554,
        "prices": {}
    },
    {
        "id": "viada-viada-55-9546417-23-3162034",
        "brand": "Viada",
        "name": "Viada",
        "address": "J. Basanavičiaus g. 122A, Šiauliai, 76161",
        "city": "Šiauliai",
        "lat": 55.9546417,
        "lon": 23.3162034,
        "prices": {}
    },
    {
        "id": "viada-viada-55-9264011-23-3076316",
        "brand": "Viada",
        "name": "Viada",
        "address": "Dubijos g. 1C, Šiauliai, 77158",
        "city": "Šiauliai",
        "lat": 55.9264011,
        "lon": 23.3076316,
        "prices": {}
    },
    {
        "id": "viada-viada-55-6701278-24-3498056",
        "brand": "Viada",
        "name": "Viada",
        "address": "Panevėžio aplinkl. 5, Šilagalys",
        "city": "Šilagalys",
        "lat": 55.6701278,
        "lon": 24.3498056,
        "prices": {}
    },
    {
        "id": "viada-viada-55-4900641-22-20019",
        "brand": "Viada",
        "name": "Viada",
        "address": "Rytinio Kelio g. 2, Šilalė, 75122",
        "city": "Šilalė",
        "lat": 55.4900641,
        "lon": 22.20019,
        "prices": {}
    },
    {
        "id": "viada-viada-55-3428678-21-4966992",
        "brand": "Viada",
        "name": "Viada",
        "address": "Tilžės g. 59, Šilutė, 99168",
        "city": "Šilutė",
        "lat": 55.3428678,
        "lon": 21.4966992,
        "prices": {}
    },
    {
        "id": "viada-viada-55-0458393-24-9427315",
        "brand": "Viada",
        "name": "Viada",
        "address": "Plento g. 4, Širvintos, 19132",
        "city": "Širvintos",
        "lat": 55.0458393,
        "lon": 24.9427315,
        "prices": {}
    },
    {
        "id": "viada-viada-55-1254446-26-1453349",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vilniaus g. 50A, Švenčionys, 18123",
        "city": "Švenčionys",
        "lat": 55.1254446,
        "lon": 26.1453349,
        "prices": {}
    },
    {
        "id": "viada-viada-55-3202883-24-8746585",
        "brand": "Viada",
        "name": "Viada",
        "address": "Beržų g. 13, Šventupė",
        "city": "Šventupė",
        "lat": 55.3202883,
        "lon": 24.8746585,
        "prices": {}
    },
    {
        "id": "viada-viada-55-2665027-22-3115465",
        "brand": "Viada",
        "name": "Viada",
        "address": "Dariaus ir Girėno g. 138, Tauragė, 72194",
        "city": "Tauragė",
        "lat": 55.2665027,
        "lon": 22.3115465,
        "prices": {}
    },
    {
        "id": "viada-viada-55-2408127-22-3053303",
        "brand": "Viada",
        "name": "Viada",
        "address": "Pramonės g. 1, Tauragė, 72359",
        "city": "Tauragė",
        "lat": 55.2408127,
        "lon": 22.3053303,
        "prices": {}
    },
    {
        "id": "viada-viada-telsiai",
        "brand": "Viada",
        "name": "Viada",
        "address": "Pramonės g. 2, Telšiai",
        "city": "Telšiai",
        "lat": 55.993237,
        "lon": 22.240310,
        "prices": {}
    },
    {
        "id": "viada-viada-55-778835-24-3648",
        "brand": "Viada",
        "name": "Viada",
        "address": "Tičkūnų g. 31, Tičkūnai, 38410",
        "city": "Tičkūnai",
        "lat": 55.778835,
        "lon": 24.3648,
        "prices": {}
    },
    {
        "id": "viada-viada-54-359405-23-1840879",
        "brand": "Viada",
        "name": "Viada",
        "address": "Muitinės g. 22, Trakėnai, 69230",
        "city": "Trakėnai",
        "lat": 54.359405,
        "lon": 23.1840879,
        "prices": {}
    },
    {
        "id": "viada-viada-55-2461892-24-7431883",
        "brand": "Viada",
        "name": "Viada",
        "address": "Žiedo g. 15, Ukmergė, 20127",
        "city": "Ukmergė",
        "lat": 55.2461892,
        "lon": 24.7431883,
        "prices": {}
    },
    {
        "id": "viada-viada-55-4970016-25-6307779",
        "brand": "Viada",
        "name": "Viada",
        "address": "Metalo g. 8, Utena, 28217",
        "city": "Utena",
        "lat": 55.4970016,
        "lon": 25.6307779,
        "prices": {}
    },
    {
        "id": "viada-viada-55-4900614-25-6509863",
        "brand": "Viada",
        "name": "Viada",
        "address": "Pramonės g. 25, Utena, 28216",
        "city": "Utena",
        "lat": 55.4900614,
        "lon": 25.6509863,
        "prices": {}
    },
    {
        "id": "viada-viada-54-3646477-24-8372767",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vilniaus g. 6, Valkininkai, 65438",
        "city": "Valkininkai",
        "lat": 54.3646477,
        "lon": 24.8372767,
        "prices": {}
    },
    {
        "id": "viada-viada-55-3867046-22-9013435",
        "brand": "Viada",
        "name": "Viada",
        "address": "5, Vejukai",
        "city": "Vejukai",
        "lat": 55.3867046,
        "lon": 22.9013435,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7711498-24-8209826",
        "brand": "Viada",
        "name": "Viada",
        "address": "Kauno g. 26A, Vievis, 21376",
        "city": "Vievis",
        "lat": 54.7711498,
        "lon": 24.8209826,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7752191-24-8104952",
        "brand": "Viada",
        "name": "Viada",
        "address": "Kauno g. 55A, Vievis, 21371",
        "city": "Vievis",
        "lat": 54.7752191,
        "lon": 24.8104952,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6476229-23-0292475",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vytauto g. 105, Vilkaviškis, 70118",
        "city": "Vilkaviškis",
        "lat": 54.6476229,
        "lon": 23.0292475,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7025557-25-2190197",
        "brand": "Viada",
        "name": "Viada",
        "address": "Justiniškių g. 10, Vilnius",
        "city": "Vilnius",
        "lat": 54.7025557,
        "lon": 25.2190197,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6992459-25-2601956",
        "brand": "Viada",
        "name": "Viada",
        "address": "Saltoniškių g. 12, Vilnius, 08105",
        "city": "Vilnius",
        "lat": 54.6992459,
        "lon": 25.2601956,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7263499-25-3265765",
        "brand": "Viada",
        "name": "Viada",
        "address": "Nemenčinės pl. 5, Vilnius, 10105",
        "city": "Vilnius",
        "lat": 54.7263499,
        "lon": 25.3265765,
        "prices": {}
    },
    {
        "id": "viada-viada-54-671123-25-262349",
        "brand": "Viada",
        "name": "Viada",
        "address": "Naugarduko g. 74, Vilnius, 03203",
        "city": "Vilnius",
        "lat": 54.671123,
        "lon": 25.262349,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7357563-25-2584607",
        "brand": "Viada",
        "name": "Viada",
        "address": "Ateities g. 17B, Vilnius, 08303",
        "city": "Vilnius",
        "lat": 54.7357563,
        "lon": 25.2584607,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6695608-25-2790539",
        "brand": "Viada",
        "name": "Viada",
        "address": "Sodų g. 44, Vilnius, 01312",
        "city": "Vilnius",
        "lat": 54.6695608,
        "lon": 25.2790539,
        "prices": {}
    },
    {
        "id": "viada-viada-54-665014-25-2464071",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vilkpėdės g. 2, Vilnius, 03151",
        "city": "Vilnius",
        "lat": 54.665014,
        "lon": 25.2464071,
        "prices": {}
    },
    {
        "id": "viada-viada-54-647521-25-3040707",
        "brand": "Viada",
        "name": "Viada",
        "address": "Liepkalnio g. 128A, Vilnius",
        "city": "Vilnius",
        "lat": 54.647521,
        "lon": 25.3040707,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6332962-25-1507286",
        "brand": "Viada",
        "name": "Viada",
        "address": "Kirtimų g. 29, Vilnius, 02244",
        "city": "Vilnius",
        "lat": 54.6332962,
        "lon": 25.1507286,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7137924-25-2770784",
        "brand": "Viada",
        "name": "Viada",
        "address": "Ozo g. 12, Vilnius, 08200",
        "city": "Vilnius",
        "lat": 54.7137924,
        "lon": 25.2770784,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6742264-25-222726",
        "brand": "Viada",
        "name": "Viada",
        "address": "Laisvės pr. 8, Vilnius, 04215",
        "city": "Vilnius",
        "lat": 54.6742264,
        "lon": 25.222726,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6673528-25-1738433",
        "brand": "Viada",
        "name": "Viada",
        "address": "Gariūnų g. 16A, Vilnius",
        "city": "Vilnius",
        "lat": 54.6673528,
        "lon": 25.1738433,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6529527-25-2722041",
        "brand": "Viada",
        "name": "Viada",
        "address": "Dariaus ir Girėno g. 30A, Vilnius, 02169",
        "city": "Vilnius",
        "lat": 54.6529527,
        "lon": 25.2722041,
        "prices": {}
    },
    {
        "id": "viada-viada-54-6819317-25-3140071",
        "brand": "Viada",
        "name": "Viada",
        "address": "Olandų g. 57, Vilnius, 01205",
        "city": "Vilnius",
        "lat": 54.6819317,
        "lon": 25.3140071,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7215435-25-2949823",
        "brand": "Viada",
        "name": "Viada",
        "address": "Verkių g. 52, Vilnius, 09109",
        "city": "Vilnius",
        "lat": 54.7215435,
        "lon": 25.2949823,
        "prices": {}
    },
    {
        "id": "viada-viada-54-7030388-25-2041324",
        "brand": "Viada",
        "name": "Viada",
        "address": "Pilaitės pr. 13, Vilnius, 06264",
        "city": "Vilnius",
        "lat": 54.7030388,
        "lon": 25.2041324,
        "prices": {}
    },
    {
        "id": "viada-viada-55-5945854-26-438715",
        "brand": "Viada",
        "name": "Viada",
        "address": "Statybininkų g. 1, Visaginas, 31137",
        "city": "Visaginas",
        "lat": 55.5945854,
        "lon": 26.438715,
        "prices": {}
    },
    {
        "id": "viada-viada-55-594946-26-4563923",
        "brand": "Viada",
        "name": "Viada",
        "address": "Taikos pr. 23B, Visaginas",
        "city": "Visaginas",
        "lat": 55.594946,
        "lon": 26.4563923,
        "prices": {}
    },
    {
        "id": "viada-viada-54-9270913-23-6619909",
        "brand": "Viada",
        "name": "Viada",
        "address": "Vytauto g. 20A, Zapyškis",
        "city": "Zapyškis",
        "lat": 54.9270913,
        "lon": 23.6619909,
        "prices": {}
    }
];
}
